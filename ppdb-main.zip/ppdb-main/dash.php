<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

</head>
<body>
    <div class="left-panel w-[300px] bg-[#0B2447] h-screen text-white p-6">
        <p class="text-2xl mb-3">Admin PPDB</p>
        <hr>
        <nav class="flex flex-col gap-4 mt-6">
            <a href="dash.php">Dashboard</a>
            <a href="data-pendaftaran.php">Data pendaftar</a>
            <a href="verif-data.php"></a>
        </nav>
    </div>
</body>
</html>