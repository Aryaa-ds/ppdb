<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

</head>
<body class="bg-[#0B2447]">
    <nav class="bg-white w-full h-[80px] flex justify-between items-center p-4">
        <p class= "text-2xl ">DAFTAR</p>
        <a class="text-[#2E7D32] p-2 rounded-md border border-[#2E7D32]" href="index.php">Kembali</a>
    </nav>
    <div class="main p-10">
        <div class="form w-full bg-white p-10 rounded-lg flex flex-col items-center gap-5">
            <img class="w-25" src="img/form.webp" alt="gambar form">
            <p>Isi Formulir Pendaftaran</p>
            <a class="bg-[#2E7D32] p-2 rounded-md text-white hover: " href="form.php">Isi Formulir </a>
        </div>
        <div class="search w-full bg-white p-10 rounded-lg mt-10 gap-5">
            <p class="text-2xl">Lihat status pendaftaran</p>
            <br>
            <div class="inpt flex flex-row justify-end">
                <div class="w-1/3">
                    <label for="search">Masukan Nomor registrasi</label> 
                    <br>
                    <input class="input border border-[#0B2447] p-2 rounded-md" type="text" name="search" id="search" placeholder="Cari.."/> 
                    <button class="bg-[#0B2447] px-5 py-2 rounded-md text-white" type="submit">Cari</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>